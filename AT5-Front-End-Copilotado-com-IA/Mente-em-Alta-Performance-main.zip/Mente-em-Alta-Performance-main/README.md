# Mente em Alta Performance

## Ansiedade na era da produtividade

Projeto acadêmico desenvolvido para abordar como a cobrança por resultados e a inteligência artificial afetam a saúde emocional dos jovens profissionais.

## Objetivo

Promover a reflexão sobre a relação entre produtividade, tecnologia, inteligência artificial e saúde emocional, incentivando hábitos mais equilibrados.

## Conteúdo do site

O projeto possui as seguintes páginas:

- **Início:** apresentação do projeto.
- **Produtividade:** reflexões sobre a cobrança por resultados.
- **Inteligência Artificial:** impactos da tecnologia no ambiente profissional.
- **Saúde Emocional:** conteúdos sobre bem-estar.
- **Pesquisas:** apresentação de dados e informações.
- **Equilíbrio:** orientações e teste interativo sobre a rotina.
- **Sobre o projeto:** informações sobre o desenvolvimento.

## Tecnologias utilizadas

- HTML5
- CSS3
- JavaScript
- Bootstrap 5
- Chart.js
- ChartDataLabels
- Git e GitHub

## Funcionalidades

- Navegação entre diferentes páginas.
- Alternância entre tema claro e escuro.
- Salvamento da preferência de tema com localStorage.
- Gráfico interativo com dados de pesquisa.
- Microaplicação para reflexão sobre equilíbrio na rotina.
- Layout responsivo.

## Organização dos arquivos

```text
Mente-em-Alta-Performance/
├── assets/
│   ├── img/
│   └── icons